const tg = window.Telegram.WebApp;
tg.expand(); // Telegramda to'liq oynada ochish

const products = ["Pechini 1", "Pechini 2", "Pechini 3", "Pechini 4", "Pechini 5", "Pechini 6"];
const cart = {};
products.forEach(p => cart[p] = 0);

let selectedPayment = null;

// HTML Elementlarni ulash
const App = document.getElementById('app');
const PaymentScreen = document.getElementById('paymentScreen');
const productsGrid = document.getElementById('productsGrid');
const btnNext = document.getElementById('btnNext');
const btnBack = document.getElementById('btnBack');
const btnConfirm = document.getElementById('btnConfirm');
const payCards = document.querySelectorAll('.pay-card');

// Mahsulotlarni chizish
function renderProducts() {
    productsGrid.innerHTML = '';
    products.forEach(p => {
        const card = document.createElement('div');
        card.className = 'product-card glass';
        card.innerHTML = `
            <div class="pro-icon">🍪</div>
            <div class="pro-title">${p}</div>
            <div class="counter">
                <button class="c-btn" onclick="updateQty('${p}', -1)">-</button>
                <div class="c-val">${cart[p]}</div>
                <button class="c-btn" onclick="updateQty('${p}', 1)">+</button>
            </div>
        `;
        productsGrid.appendChild(card);
    });
    updateCheckoutData();
}

// Miqdorlarni almashtirish
window.updateQty = function(id, change) {
    if (cart[id] + change >= 0 && cart[id] + change <= 100) {
        cart[id] += change;
        renderProducts();
        try { tg.HapticFeedback.impactOccurred('light'); } catch(e){} // Telefon titrashi
    }
}

// Savatchani yangilash
function updateCheckoutData() {
    const totalBoxes = Object.values(cart).reduce((a, b) => a + b, 0);
    
    if (totalBoxes > 0) {
        btnNext.innerText = `To'lovga o'tish (${totalBoxes} quti)`;
        btnNext.classList.remove('disabled');
    } else {
        btnNext.innerText = `Savatcha bo'sh`;
        btnNext.classList.add('disabled');
    }
}

// Birinchi sahifadan ikkinchisiga o'tish
btnNext.addEventListener('click', () => {
    App.classList.remove('active');
    PaymentScreen.classList.add('active');
    try { tg.HapticFeedback.impactOccurred('medium'); } catch(e){}
});

// Orqaga qaytish
btnBack.addEventListener('click', () => {
    PaymentScreen.classList.remove('active');
    App.classList.add('active');
});

// To'lov turini tanlash
payCards.forEach(card => {
    card.addEventListener('click', () => {
        payCards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        
        selectedPayment = card.getAttribute('data-method');
        btnConfirm.classList.remove('disabled');
        try { tg.HapticFeedback.selectionChanged(); } catch(e){}
    });
});

// Eng oxirida botga ma'lumotni kiritib yuborish
btnConfirm.addEventListener('click', () => {
    const finalData = { 
        cart: cart, 
        payment: selectedPayment 
    };
    
    // Telegram Botga (app data content type qilib) yuborish
    tg.sendData(JSON.stringify(finalData));
    tg.close(); // Miniappni yopish
});

// Ishga tushurish
renderProducts();
